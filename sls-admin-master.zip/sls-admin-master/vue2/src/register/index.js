import {
	request as apis
} from 'config/';

import {
	ajax
} from 'util/';

module.exports = {
	plugins: {
		apis,
		ajax
	}
};