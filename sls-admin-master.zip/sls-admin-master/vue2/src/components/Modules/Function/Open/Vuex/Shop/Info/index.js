import Info from './Info.vue';
module.exports = Info;