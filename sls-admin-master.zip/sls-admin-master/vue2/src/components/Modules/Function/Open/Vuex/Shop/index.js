import Info from './Info/';
import List from './List/';
import Cart from './Cart/';
module.exports = {
    Info,
    List,
    Cart
};