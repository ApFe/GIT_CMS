import Test404 from './Test404.vue';
module.exports = Test404;