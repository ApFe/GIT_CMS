module.exports = {
    Bar: require('./Bar/'),
    Pie: require('./Pie/')
};