import Pie from './Pie.vue';
module.exports = Pie;