module.exports = {
	Article: require('./Article/'),
	Wangeditor: require('./Wangeditor/'),
	Components: require('./Components/'),
};