module.exports = {
    Edit: require('./Edit/'),
    List: require('./List/')
};