import List from './List.vue';
module.exports = List;