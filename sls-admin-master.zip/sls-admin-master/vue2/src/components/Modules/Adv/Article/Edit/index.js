import Edit from './Edit.vue';
module.exports = Edit;