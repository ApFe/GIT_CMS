module.exports = {
	Many: require('./Many/'),
	One: require('./One/')
};