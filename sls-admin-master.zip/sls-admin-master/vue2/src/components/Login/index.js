import Login from './Login.vue';
module.exports = Login;