import ListData from './ListData.vue';
module.exports = ListData;