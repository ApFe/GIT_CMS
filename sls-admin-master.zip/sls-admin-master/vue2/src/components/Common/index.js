module.exports = {
	Bread: require('./Bread/Bread.vue'),
	HeadNav: require('./HeadNav/HeadNav.vue'),
	LeftMenu: require('./LeftMenu/LeftMenu.vue'),
	Echarts: require('./Echarts/'),
	ListData: require('./ListData/'),
	FormData: require('./FormData/'),
	DialogInfo: require('./DialogInfo/'),
};