<template>
    <section class="chart">
        <el-row>
            <el-col :span="24">
                <div id="chartDom" style="width:100%; height:400px;"></div>
            </el-col>
        </el-row>
    </section>
</template>
<script>
    import DefaultJs from './Default.js';
    module.exports=DefaultJs;
</script>
<style scoped>
    
</style>
