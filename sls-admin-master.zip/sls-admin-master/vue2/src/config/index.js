module.exports = {
	routes: require('./router.js'),
	settings: require('./settings.js'),
	request: require('./request.js')
};