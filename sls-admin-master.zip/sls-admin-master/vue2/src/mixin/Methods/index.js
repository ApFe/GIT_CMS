module.exports = {
	Common: require('./Common/')
};