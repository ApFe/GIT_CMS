module.exports = {
	store: require('./store/'),
	ajax: require('./ajax/')
};