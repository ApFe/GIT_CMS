<<<<<<< HEAD
### Usage

This is a project template for [vue-cli](https://github.com/vuejs/vue-cli).

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8081
npm run dev

# build for production with minification
npm run build

```

### Browser Support

Modern browsers and Internet Explorer 10+.

### snapshots
![image](https://raw.githubusercontent.com/taylorchen709/markdown-images/master/vueadmin/login.png)
![image](https://raw.githubusercontent.com/taylorchen709/markdown-images/master/vueadmin/main.png)
![image](https://raw.githubusercontent.com/taylorchen709/markdown-images/master/vueadmin/edit.jpg)

### License
[MIT](http://opensource.org/licenses/MIT)
=======
# CMS
项目--后台
>>>>>>> 8c060c1947541bc7a9cd8efbf4fb4b1084f1ec13
