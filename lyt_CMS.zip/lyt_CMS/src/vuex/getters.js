//test
export const getCount = state => {
    return state.count
}
