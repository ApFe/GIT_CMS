
//const host = 'http://10.48.154.203/loyaltyApp';
const host = 'http://10.48.2.57:8080/loyaltyApp';
//const host =process.env.API_ROOT;
export default {
  host
};