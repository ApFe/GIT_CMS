module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"//www.baidu.com/api"'//线上地址
}
